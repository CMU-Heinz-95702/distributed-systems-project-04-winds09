package ds.cmu.edu;

/*
 * @author Yueyue Ji
 * @andrewID yueyuej
 * @date 2024.11.23
 */

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Build;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
/**
 * MainActivity is the main entry point for the Android application.
 * It allows users to fetch number facts from a web service and display them.
 *
 * <p>This activity performs the following tasks:
 * <ul>
 *   <li>Initializes UI components</li>
 *   <li>Sets up event listeners for buttons and spinner</li>
 *   <li>Fetches number facts from a web service</li>
 *   <li>Displays the fetched facts</li>
 * </ul>
 * </p>
 */
public class MainActivity extends AppCompatActivity {

    private EditText numberInput;
    private Spinner typeSpinner;
    private Button fetchButton;
    private Button randomButton;
    private TextView resultText;

    private String selectedType = "trivia"; // Default type

    // Local address for the emulator to access the host machine
    // private static final String WEB_SERVICE_URL = "http://10.0.2.2:8080/InterestingPicture-1.0-SNAPSHOT/numberfact";
    // GitHub Codespaces address for the emulator to access the host machine
    private static final String WEB_SERVICE_URL = "https://scaling-space-spork-wwgpv5pwpwrf9699-8080.app.github.dev/numberfact";

    /**
     * Called when the activity is first created.
     * Initializes the UI components and sets up event listeners.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down then this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        numberInput = findViewById(R.id.numberInput);
        typeSpinner = findViewById(R.id.typeSpinner);
        fetchButton = findViewById(R.id.fetchButton);
        randomButton = findViewById(R.id.randomButton);
        resultText = findViewById(R.id.resultText);

        // Set up the spinner (dropdown) for fact types
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.fact_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(adapter);

        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedType = adapterView.getItemAtPosition(i).toString().toLowerCase();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedType = "trivia";
            }
        });

        // Set up listeners for buttons
        fetchButton.setOnClickListener(view -> fetchFact(false));
        randomButton.setOnClickListener(view -> fetchFact(true));
    }

    /**
     * Fetches a number fact from the web service.
     *
     * @param isRandom If true, fetches a random fact; otherwise, fetches a fact for the specified number.
     */
    private void fetchFact(boolean isRandom) {
        String number = numberInput.getText().toString().trim();
        if (isRandom) {
            number = ""; // Ignore input for random query
        }

        // Build the query URL
        StringBuilder urlBuilder = new StringBuilder(WEB_SERVICE_URL);
        urlBuilder.append("?type=").append(selectedType);

        if (!number.isEmpty()) {
            urlBuilder.append("&number=").append(number);
        }

        // Get device information
        String deviceModel = Build.MODEL;
        String androidVersion = Build.VERSION.RELEASE;

        try {
            urlBuilder.append("&model=").append(URLEncoder.encode(deviceModel, "UTF-8"));
            urlBuilder.append("&android_version=").append(URLEncoder.encode(androidVersion, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String queryUrl = urlBuilder.toString();

        // Perform the network request in a new thread
        new Thread(() -> {
            try {
                URL url = new URL(queryUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                // Get the response code
                int status = conn.getResponseCode();

                if (status == HttpURLConnection.HTTP_OK) {
                    // Read the response
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    String inputLine;
                    StringBuilder content = new StringBuilder();

                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }
                    in.close();

                    // Update UI with the fetched data
                    String jsonResponse = content.toString();
                    runOnUiThread(() -> displayResult(jsonResponse));

                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Error fetching data. Status code: " + status,
                            Toast.LENGTH_LONG).show());
                }

            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Network error occurred.",
                        Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /**
     * Displays the fetched number fact in the UI.
     *
     * @param jsonResponse The JSON response from the web service.
     */
    private void displayResult(String jsonResponse) {
        try {
            // Parse the JSON response
            org.json.JSONObject jsonObject = new org.json.JSONObject(jsonResponse);
            String text = jsonObject.getString("text");
            int number = jsonObject.getInt("number");
            String type = jsonObject.getString("type");

            String displayText = "Fact about " + number + " (" + type + "):\n" + text;
            resultText.setText(displayText);

        } catch (org.json.JSONException e) {
            e.printStackTrace();
            resultText.setText("Error parsing JSON response.");
        }
    }
}