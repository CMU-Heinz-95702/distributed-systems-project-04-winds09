package ds;

/*
  @author Yueyue Ji
 * @andrewID yueyuej
 * @date 2024.11.23
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.mongodb.client.*;
import org.bson.Document;
import com.mongodb.client.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * DashboardServlet acts as the Controller for the dashboard.
 * It retrieves data from the database and forwards it to the JSP for presentation.
 * This servlet performs the following tasks:
 *   Retrieves the largest number queried
 *   Finds the most frequently queried number
 *   Identifies the top 5 Android phone models making requests
 *   Fetches the last 20 requests
 */
@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private MongoClient mongoClient;

    /**
     * Initializes the servlet and MongoDB client.
     *
     * @throws ServletException if an initialization error occurs
     */
    @Override
    public void init() throws ServletException {
        super.init();
        String uri = "mongodb+srv://Cluster36659:vvcjES1WmL05IXif@cluster0.7iipo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        mongoClient = MongoClients.create(uri);
    }

    /**
     * Handles GET requests to the /dashboard URL.
     * Retrieves data from the database and forwards it to the JSP for presentation.
     *
     * @param request the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @throws ServletException if a servlet error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Connect to database and collection
            MongoDatabase database = mongoClient.getDatabase("numberfactsdb");
            MongoCollection<Document> collection = database.getCollection("logs");

            // 1. The largest number queried (use 'response_number')
            Document largestNumberDoc = collection.find(
                    Filters.exists("response_number", true)
            ).sort(Sorts.descending("response_number")).first();
            String largestNumber = "N/A";
            if (largestNumberDoc != null) {
                Object numObj = largestNumberDoc.get("response_number");
                if (numObj != null) {
                    largestNumber = numObj.toString();
                }
            }

            // 2. The most frequently queried number (If multiple candidates, return the largest)
            List<Document> freqNumbers = collection.aggregate(List.of(
                    Aggregates.match(Filters.exists("response_number", true)),
                    Aggregates.group("$response_number", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.orderBy(Sorts.descending("count"), Sorts.descending("_id"))),
                    Aggregates.limit(1)
            )).into(new ArrayList<>());

            String mostFrequentNumber = "N/A";
            if (!freqNumbers.isEmpty()) {
                mostFrequentNumber = freqNumbers.get(0).get("_id").toString();
            }

            // 3. Top 5 Android phone models making requests
            List<Document> topModels = collection.aggregate(List.of(
                    Aggregates.group("$mobile_model", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(5)
            )).into(new ArrayList<>());

            // 4. Last 20 requests
            List<Document> last20Logs = collection.find()
                    .sort(Sorts.descending("timestamp"))
                    .limit(20)
                    .into(new ArrayList<>());

            // Set attributes to pass to JSP
            request.setAttribute("largestNumber", largestNumber);
            request.setAttribute("mostFrequentNumber", mostFrequentNumber);
            request.setAttribute("topModels", topModels);
            request.setAttribute("last20Logs", last20Logs);

            // Forward to JSP
            request.getRequestDispatcher("index.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            // Handle exception and display error page or message
            request.setAttribute("errorMessage", "An error occurred while processing the dashboard data.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    /**
     * Destroys the servlet and closes the MongoDB client.
     */
    @Override
    public void destroy() {
        // Close MongoDB client
        if (mongoClient != null) {
            mongoClient.close();
        }
        super.destroy();
    }
}