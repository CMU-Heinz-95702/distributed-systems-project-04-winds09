package ds;

/*
  @author Yueyue Ji
 * @andrewID yueyuej
 * @date 2024.11.23
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.bson.Document;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.json.JSONObject;
/**
 * This class handles interactions with the Numbers API and MongoDB.
 *
 * <p>It provides methods to fetch number facts from the Numbers API and log the data to MongoDB.</p>
 *
 * <p>Usage example:</p>
 * <pre>
 * {@code
 * NumberFactModel model = new NumberFactModel();
 * String fact = model.getNumberFact("math", "42");
 * model.logData("math", "42", fact, "Pixel 4", "Android 11", "192.168.1.1", System.currentTimeMillis(), System.currentTimeMillis());
 * model.close();
 * }
 * </pre>
 */
public class NumberFactModel {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;
    /**
     * Constructs a new NumberFactModel and initializes the MongoDB client.
     */
    public NumberFactModel() {
        // Initialize MongoDB client
        String uri = "mongodb+srv://Cluster36659:vvcjES1WmL05IXif@cluster0.7iipo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        mongoClient = MongoClients.create(uri);
        database = mongoClient.getDatabase("numberfactsdb");
        collection = database.getCollection("logs");
    }

    /**
     * Fetches a number fact from the Numbers API based on the type and number provided.
     *
     * @param type The type of fact (e.g., "year", "math", "trivia").
     * @param number The specific number to query. If null or "random", fetches a random fact.
     * @return The JSON response as a String.
     * @throws IOException If an input or output exception occurred.
     */
    public String getNumberFact(String type, String number) throws IOException {
        // Encode the type parameter to be safe
        String encodedType = URLEncoder.encode(type, StandardCharsets.UTF_8.name());
        String apiUrl;

        if (number != null && !number.isEmpty() && !number.equalsIgnoreCase("random")) {
            // Use the specified number
            String encodedNumber = URLEncoder.encode(number, StandardCharsets.UTF_8.name());
            apiUrl = "http://numbersapi.com/" + encodedNumber + "/" + encodedType + "?json";
        } else {
            // Fetch a random fact
            apiUrl = "http://numbersapi.com/random/" + encodedType + "?json";
        }

        // Fetch data from the Numbers API
        String response = fetch(apiUrl);

        // Note: Logging is now handled in the servlet after response is obtained

        return response; // JSON response as a String
    }

    /**
     * Makes an HTTP GET request to the specified URL and returns the response as a String.
     *
     * @param urlString The URL to fetch data from.
     * @return The response from the server.
     * @throws IOException If an input or output exception occurred.
     */
    private String fetch(String urlString) throws IOException {
        StringBuilder response = new StringBuilder();

        URL url = new URL(urlString);
        // Open connection
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        // Check if the response code is HTTP 200 OK
        int status = conn.getResponseCode();
        if (status != HttpURLConnection.HTTP_OK) {
            throw new IOException("Failed to fetch data from Numbers API, HTTP response code: " + status);
        }

        // Read response
        BufferedReader in = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)
        );
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return response.toString();
    }

    /**
     * Logs the data to MongoDB.
     *
     * @param type          The type of fact requested.
     * @param number        The specific number requested, or "Random" if it was a random request.
     * @param response      The JSON response from the Numbers API.
     * @param mobileModel   The mobile phone model making the request.
     * @param androidVersion The Android version of the device.
     * @param userIP        The user's IP address.
     * @param requestTime   The time the request was made.
     * @param replyTime     The time the reply was sent.
     */
    public void logData(String type, String number, String response, String mobileModel, String androidVersion, String userIP, long requestTime, long replyTime) {
        try {
            // Parse the response to extract the actual number
            JSONObject jsonResponse = new JSONObject(response);
            Object actualNumberObj = jsonResponse.get("number");
            int responseNumber = 0;
            if (actualNumberObj instanceof Integer) {
                responseNumber = (Integer) actualNumberObj;
            } else if (actualNumberObj instanceof Long) {
                responseNumber = ((Long) actualNumberObj).intValue();
            } else if (actualNumberObj instanceof String) {
                try {
                    responseNumber = Integer.parseInt((String) actualNumberObj);
                } catch (NumberFormatException e) {
                    responseNumber = 0; // Default or handle accordingly
                }
            }

            String requestNumber;
            if (number != null && !number.isEmpty()) {
                if (number.equalsIgnoreCase("random")) {
                    requestNumber = "Random";
                } else {
                    requestNumber = number;
                }
            } else {
                requestNumber = "Random";
            }

            Document logEntry = new Document("type", type)
                    .append("request_number", requestNumber)
                    .append("response_number", responseNumber)
                    .append("response", response)
                    .append("mobile_model", (mobileModel != null && !mobileModel.isEmpty()) ? mobileModel : "Unknown")
                    .append("android_version", (androidVersion != null && !androidVersion.isEmpty()) ? androidVersion : "Unknown")
                    .append("user_ip", (userIP != null && !userIP.isEmpty()) ? userIP : "Unknown")
                    .append("request_time", new java.util.Date(requestTime))
                    .append("reply_time", new java.util.Date(replyTime))
                    .append("timestamp", new java.util.Date());

            // Insert the document into the collection
            collection.insertOne(logEntry);
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception to the server logs
        }
    }

    /**
     * Closes the MongoDB client.
     */
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
