package ds;

/*
 * @author Yueyue Ji
 * @andrewID yueyuej
 * @data 2024.11.23
 *
 * This file is the Controller component of the MVC pattern. It handles HTTP GET requests
 * from the Android application, interacts with the Model to process data, and sends
 * JSON responses back to the client.
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "NumberFactServlet", urlPatterns = {"/numberfact"})
public class NumberFactServlet extends HttpServlet {

    private NumberFactModel model = null;

    @Override
    public void init() {
        model = new NumberFactModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the 'type' and 'number' parameters from the request
        String type = request.getParameter("type"); // e.g., "year", "math", "trivia"
        String number = request.getParameter("number"); // Specific number or "random"

        // Get additional parameters
        String modelParam = request.getParameter("model"); // Mobile phone model
        String androidVersion = request.getParameter("android_version"); // Android version
        String userIP = request.getRemoteAddr(); // User's IP address

        // Record request time
        long requestTime = System.currentTimeMillis();

        // Set response content type to JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        if (type != null && !type.isEmpty()) {
            try {
                // Use the model to get the number fact
                String jsonResponse = model.getNumberFact(type, number);

                // Record reply time
                long replyTime = System.currentTimeMillis();

                // Log data
                model.logData(type, number, jsonResponse, modelParam, androidVersion, userIP, requestTime, replyTime);

                // Write the response back to the client
                out.print(jsonResponse);
                out.flush();
            } catch (IOException e) {
                e.printStackTrace(); // Log the exception
                // Handle error when fetching data from Numbers API
                response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
                out.print("{\"error\":\"Unable to fetch data from Numbers API.\"}");
                out.flush();
            } catch (Exception e) {
                e.printStackTrace(); // Log the exception
                // Handle other exceptions
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print("{\"error\":\"An unexpected error occurred: " + e.getMessage() + "\"}");
                out.flush();
            }
        } else {
            // Handle invalid input
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"error\":\"Invalid 'type' parameter. Please specify 'year', 'math', or 'trivia'.\"}");
            out.flush();
        }
    }

    @Override
    public void destroy() {
        // Close the MongoDB client when the servlet is destroyed
        if (model != null) {
            model.close();
        }
    }
}
